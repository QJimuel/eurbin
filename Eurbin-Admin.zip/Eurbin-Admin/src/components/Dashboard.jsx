
function Dashboard() {

    
    return<>

    <h1 className="headings"> Dashboard </h1>

    
      <div className="dbParent">

        <div className="dashboardBox1">
          <div className="dbox">
            <img src={user} alt="" />
            <div>
              <p className='dbNum'>90</p>
              <p>Total Users</p>
            </div>
          </div>
        </div>

        <div className="dashboardBox1">
        <div className="dbox">
            <img src={user} alt="" />
            <div>
              <p className='dbNum'>90</p>
              <p>Total Bottles</p>
            </div>
          </div>
        </div>

        <div className="dashboardBox1">
        <div className="dbox">
            <img src={user} alt="" />
            <div>
              <p className='dbNum'>90</p>
              <p>Total CO2</p>
            </div>
          </div>
        </div>

        <div className="dashboardBox1">
          <div className="dbox">
            <img src={user} alt="" />
            <div>
              <p className='dbNum'>90</p>
              <p>Total Points</p>
            </div>
          </div>
        </div>

      </div>

      

     
   
</> ;
    
}
export default Dashboard;