
import { useEffect, useState } from 'react';
import axios from 'axios';
import { Outlet, Link } from "react-router-dom";

function UserManagement() {
    const API_URL = 'http://localhost:7000/user';
    const [user, setUser] = useState([]);

    useEffect(() => {
        fetchUser();
      }, []);
    
      const fetchUser = async () => {
        try {
          const response = await axios.get(API_URL);
        
          if (response.status === 200 && response.data.users) {
        
            setUser(response.data.users);
          } else {
            console.error('Unexpected data format:', response.data);
            alert('An error occurred: Unexpected data format');
          }
        } catch (err) {
          console.error('Error fetching totals:', err);
          alert('An error occurred while fetching totals');
        }
      };

    
    return<>
        <h1 className="headings"> User Management </h1>

        <nav className="nav">
            <ul className="navList">
            <li >
                <Link to="/ManageUser" >
                <button className={location.pathname === "/ManageUser" ? "active-btn" : "inactive-btn"}>
                        Active Users
                    </button>
                </Link>
            </li>
            <li >
                <Link to="" >
                <button className={location.pathname === "/Request" ? "active-btn" : "inactive-btn"}>
                        Deactivated Users
                    </button>
                </Link>
            </li>
            <li >
                <Link to="" >
                <button className={location.pathname === "/Transaction" ? "active-btn" : "inactive-btn"}>
                        T
                    </button>
                </Link>
            </li>
            <li >
                <Link to="" >
                <button className={location.pathname === "/Recycleables" ? "active-btn" : "inactive-btn"}>
                        Re
                    </button>
                </Link>
            </li>
            </ul>
        </nav>
      <br/>
      <br/>
      <br/>
         
       


        <div className="table-container">
            <table className="w3-table-all">
                <thead>
                    <tr className="w3-light-grey">
                        <th>User Id</th>
                        <th>User Name</th>
                        <th>Smart Points</th>
                        <th>Plastic Bottle</th>
                        <th>Co2</th>
                    
               
                    </tr>
                </thead>
                <tbody>
                    {user.map(item => (
                        <tr key={user._id}>
        
                            <td>{item.userId}</td>
                            <td>{item.userName}</td>
                            <td>{item.smartPoints}</td>
                            <td>{item.plasticBottle}</td>
                            <td>{item.co2}</td>
                            
                            
                        </tr>
                    ))}
                </tbody>
            </table>
    
            </div>


    
    </> ;
    
}
export default UserManagement;