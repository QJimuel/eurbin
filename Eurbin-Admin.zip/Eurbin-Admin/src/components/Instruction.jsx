function Instruction() {

    
    return<>
        <h1 className="headings"> Instruction </h1>

        <div className="instructionContent">
            <div className="iContent">
                <div className="step">
                    <b>Step 1</b>
                    <p>Video provides a powerful way to help you prove your point.</p>
                </div>
                <div className="step">
                    <b>Step 1</b>
                    <p>Video provides a powerful way to help you prove your point.</p>
                </div>
                <div className="step">
                    <b>Step 1</b>
                    <p>Video provides a powerful way to help you prove your point.</p>
                </div>
            </div>
        </div>

    
    </> ;
    
}
export default Instruction;